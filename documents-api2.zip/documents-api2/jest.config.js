
module.exports = {
  clearMocks: true,
  passWithNoTests: true,
  coverageProvider: 'v8',
  preset: 'ts-jest',
  testMatch: ['**/**/*.test.ts'],
  roots: ['<rootDir>/src']
}
