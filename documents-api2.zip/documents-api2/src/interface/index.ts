/* eslint-disable @typescript-eslint/no-misused-promises */
import { SchemaValidationMiddleware } from '../interface/middleware/schemaValidationMiddleware'
import MainRouter from './router'
import { config } from '../config'
import cors from 'cors'
import express, { Express } from 'express'
import 'express-async-errors'
import logger from 'morgan'
import { AuthValidationMiddleware } from './middleware/authValidationMiddleware'

export class ServiceServer {
  private readonly app: Express
  private readonly Router: typeof MainRouter

  constructor() {
    this.app = express()
    this.Router = MainRouter
  }

  run() {
    this.utils()
    this.essentials()
    this.app.get('/', (req, res) => {
      res.send('Hello World!')
    })
    this.app.use(AuthValidationMiddleware)
    this.app.use(SchemaValidationMiddleware)
    this.routers()
  }

  routers() {
    this.app.use('/', this.Router.run())
  }

  essentials() {
    this.app.listen(config.PORT)
  }

  utils() {
    this.app.use(express.json())
    this.app.use(cors())
    this.app.use(logger('dev'))
  }

  getApp() {
    this.utils()
    this.routers()
    this.app.use(SchemaValidationMiddleware)
    return this.app
  }
}
