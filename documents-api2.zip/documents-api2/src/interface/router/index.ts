import { Router } from 'express'
import CteRouter from '../../entities/cte'
import NfeRouter from '../../entities/nfe'

class MainRouter {
  public router: Router

  constructor () {
    this.router = Router()
  }

  run () {
    this.routes()
    return this.router
  }

  routes () {
    this.router.use('/cte', CteRouter.run())
    this.router.use('/nfe', NfeRouter.run())
  }
}

export default new MainRouter()
