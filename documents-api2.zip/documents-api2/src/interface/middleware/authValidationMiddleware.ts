import jwt from 'jsonwebtoken'
import { Response, NextFunction, Request } from 'express'
import { config } from '../../config'

interface Token {
  uid: number
}

export const AuthValidationMiddleware = async (
  request: Request & { userId: number },
  _response: Response,
  next: NextFunction
) => {
  try {
    const authHeader = request.headers.authorization

    if (!authHeader) {
      throw {
        status: 401,
        message: 'Unauthorized'
      }
    }

    const [, token] = authHeader.split(' ')
    const decoded = jwt.verify(token, config.JWT_SECRET) as Token

    request.userId = (decoded).uid

    return next()
  } catch (err) {
    return next({ status: 401, message: 'Unauthorized' })
  }
}
