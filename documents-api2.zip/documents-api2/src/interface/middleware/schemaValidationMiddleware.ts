import { NextFunction, Response } from 'express'
import { ZodError } from 'zod'
import { CargonRequest } from '../../types'
import { ErrorTypesEnum } from '../../utils/errors/ErrorTypesEnum'

export const SchemaValidationMiddleware = (err: Error | ZodError, _req: CargonRequest, res: Response, _next: NextFunction) => {
  if (err instanceof ZodError) {
    const errorMessages = err.errors.map(err => {
      return {
        message: err.message,
        type: ErrorTypesEnum.SchemaValidation
      }
    })
    return res.status(422).send(errorMessages)
  }
}
