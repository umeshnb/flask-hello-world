import dotenv from 'dotenv'
dotenv.config()

export const config = {
  DATABASE_URL: process.env.DATABASE_URL,
  PORT: process.env.PORT ?? 80,
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD,
  JWT_SECRET: process.env.JWT_SECRET ?? 'yJytu5o89Von0l83yUaMk36Oy2nehtPM',
  ISSUING_API_URL: process.env.ISSUING_API_URL ?? 'http://localhost:8070'
}
