export class ApplicationError extends Error {
  info: string | undefined
  message: string
  name: 'ApplicationError'
  code: number
  constructor (message: string, code = 400, info?: string) {
    super()
    this.info = info
    this.message = message
    this.name = 'ApplicationError'
    this.code = code
  }
}
