export enum ErrorTypesEnum {
  SchemaValidation = 'SchemaValidationError'
}
