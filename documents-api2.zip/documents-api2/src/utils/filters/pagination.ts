
export const createPagination = ({ page = 1, perPage = 50 }: { page: number, perPage: number }): { skip: number, take: number } => {
  if (isNaN(page) || isNaN(perPage)) {
    page = 1
    perPage = 50
  }

  const skip = page > 0 ? (page - 1) * perPage : perPage

  return { skip, take: perPage }
}
