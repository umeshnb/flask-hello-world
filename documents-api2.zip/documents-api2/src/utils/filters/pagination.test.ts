import { createPagination } from './pagination'

describe('unit: create pagination', () => {
  it('should convert page and perPage to number when page provided is NaN', async () => {
    const { page, perPage } = { page: Number('a'), perPage: 10 }

    const { skip, take } = createPagination({ page, perPage })

    expect(skip).toBe(0)
    expect(take).toBe(50)
  })
  it('should convert page and perPage to number when perPage provided is NaN', async () => {
    const { page, perPage } = { page: 1, perPage: Number('a') }

    const { skip, take } = createPagination({ page, perPage })

    expect(skip).toBe(0)
    expect(take).toBe(50)
  })
  it('should create pagination correctly', async () => {
    const perPage = 50
    for (let i = 1; i < 5; i++) {
      const page = i

      const { skip, take } = createPagination({ page, perPage })
      expect(skip).toBe(page > 0 ? (page - 1) * perPage : perPage)
      expect(take).toBe(50)
    }
  })
})
