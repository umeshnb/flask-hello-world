import { ResponsesUseCases } from '../../types'

export const setResponse = ({
  status,
  result,
  message
}: { status: number, result: any, message?: string }
): ResponsesUseCases<typeof result> => {
  return {
    status,
    data: {
      result,
      message
    }
  }
}
