/* eslint-disable no-console */

export async function removeDbConstraints (prisma: any) {
  try {
    await prisma.$executeRaw`EXEC sp_MSforeachtable "ALTER TABLE ? NOCHECK CONSTRAINT all"`
  } catch (err) {
    console.error(`Error removing constraints: ${err}`)
  }
}
