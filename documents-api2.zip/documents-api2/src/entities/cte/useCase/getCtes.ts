import { createContext } from '@cargon/client'
import { createPagination } from '../../../utils/filters/pagination'
import { setResponse } from '../../../utils/helpers/httpHelper'
import { PayloadGetCtesQuery, zodPayloadGetCtesQuery } from '../types'

export const getCtes = async (data: PayloadGetCtesQuery, { page = 1, perPage = 50 }) => {
  const { prisma } = createContext({})
  if (data?.from && !data?.to) {
    data = { ...data, to: new Date() }
  }

  if (data.from && data.to) {
    const fromDate = new Date(new Date(data.from).setHours(3, 0, 0, 0))
    const toDate = new Date(new Date(data.to).setHours(23, 59, 59, 0))
    data = {
      ...data,
      from: new Date(fromDate.setHours(fromDate.getHours() - 3)),
      to: toDate
    }
  }

  zodPayloadGetCtesQuery.parse(data)

  const { skip, take } = createPagination({ page: Number(page), perPage: Number(perPage) })
  const query = queryBuilder(data)

  const fullFilter = { ...query, NOT: [{ issuer_id: null }] }

  const nfes = await prisma.loadEmitted.findMany({
    skip,
    take,
    where: fullFilter,
    select: {
      id: true,
      cte_number: true,
      chave_cte: true,
      created_at: true,
      travel: {
        select: { id: true, travel_number: true }
      }
    }
  })

  const totalSize = await prisma.loadEmitted.count({ where: fullFilter })

  const response = setResponse({
    status: 200,
    result: { data: nfes, totalSize }
  })

  return response
}

interface IGetCtesQuery {
  created_at?: { gte?: Date | string, lte?: Date | string }
  issuer_id?: number
  nfeEmitted?: { some: { nfe: { chave_nf: { in?: string[] } } } }
  taker_id?: number
  cte_number?: { in?: string[] }
}

export const queryBuilder = (data: PayloadGetCtesQuery): IGetCtesQuery => {
  let query: IGetCtesQuery = {}

  const builder: { [key in keyof Required<Omit<PayloadGetCtesQuery, 'to'>>]: () => void } = {
    from: () => {
      query = { ...query, created_at: { gte: data.from, lte: data.to } }
    },
    issuer_id: () => {
      query = { ...query, issuer_id: data.issuer_id }
    },
    chave_nf: () => {
      query = { ...query, nfeEmitted: { some: { nfe: { chave_nf: { in: data.chave_nf?.split(',') } } } } }
    },
    taker_id: () => {
      query = { ...query, taker_id: data.taker_id }
    },
    cte_number: () => {
      query = { ...query, cte_number: { in: data.cte_number?.split(',') } }
    }
  }

  Object.keys(data).forEach(prop => {
    if (builder[prop]) {
      builder[prop]()
    }
  })

  return query
}
