import { GetCtesController } from './getCtes/getCtesController'
export class CteController {
  GetCtesController: GetCtesController
  constructor () {
    this.GetCtesController = new GetCtesController()
  }
}
