import { Response } from 'express'
import { CargonRequest } from '../../../../types'
import { PayloadGetCtesQuery } from '../../types'
import { getCtes } from '../../useCase/getCtes'

export class GetCtesController {
  async getCtes (
    req: CargonRequest<PayloadGetCtesQuery>,
    res: Response
  ) {
    const { page, perPage, ...rest } = req.query
    const { data, status } = await getCtes(rest, { page, perPage })
    return res.status(status).json(data)
  }
}
