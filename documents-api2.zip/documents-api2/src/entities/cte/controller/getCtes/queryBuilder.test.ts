import { queryBuilder } from '../../useCase/getCtes'

describe('unit: get ctes query builder', () => {
  it('should validate query built when dates range is provided', async () => {
    // arrange
    const query = { from: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString(), to: new Date().toISOString() }

    // act
    const queryBuilt = queryBuilder(query)

    // assert
    expect(queryBuilt).toStrictEqual({
      created_at:
      { gte: query.from, lte: query.to }
    })
  })
  it('should validate query when issuer_id is provided', async () => {
    // arrange
    const query = { issuer_id: 3 }

    // act
    const queryBuilt = queryBuilder(query)

    // assert
    expect(queryBuilt).toStrictEqual({ issuer_id: query.issuer_id })
  })
  it('should validate query when chave_nf array is provided', async () => {
    // arrange
    const query = { chave_nf: '1,2,3,4,5' }

    // act
    const queryBuilt = queryBuilder(query)

    // assert
    expect(queryBuilt).toStrictEqual({ nfeEmitted: { some: { nfe: { chave_nf: { in: query.chave_nf.split(',') } } } } })
  })
  it('should validate query when taker_id is provided', async () => {
    // arrange
    const query = { taker_id: 4 }

    // act
    const queryBuilt = queryBuilder(query)

    // assert
    expect(queryBuilt).toStrictEqual({ taker_id: query.taker_id })
  })
  it('should validate query when cte_number is provided', async () => {
    // arrange
    const query = { cte_number: '1' }

    // act
    const queryBuilt = queryBuilder(query)

    // assert
    expect(queryBuilt).toStrictEqual({ cte_number: { in: query.cte_number.split(',') } })
  })
  it('should validate query when all possible filters are provided', async () => {
    // arrange
    const query = {
      from: new Date().toISOString(),
      to: new Date((new Date().setDate(new Date().getDate() + 1))).toISOString(),
      issuer_id: 3,
      chave_nf: '1',
      taker_id: 25,
      cte_number: '1'
    }

    // act
    const queryBuilt = queryBuilder(query)

    // assert

    const expectedResult = {
      created_at: {
        gte: query.from,
        lte: query.to
      },
      issuer_id: 3,
      nfeEmitted: { some: { nfe: { chave_nf: { in: query.chave_nf.split(',') } } } },
      taker_id: 25,
      cte_number: { in: ['1'] }
    }
    expect(queryBuilt).toStrictEqual(expectedResult)
  })
})
