import { createContext } from '@cargon/client'
import * as getCtesHelper from '../../useCase/getCtes'

import request from 'supertest'
import { ServiceServer } from '../../../../interface'
import { ErrorTypesEnum } from '../../../../utils/errors/ErrorTypesEnum'

const PATH = '/cte/filter'

describe('integration: getCtes', () => {
  afterEach(() => {
    jest.clearAllMocks()
    jest.restoreAllMocks()
  })
  afterAll(async () => {
    const { prisma } = createContext({})
    await prisma.loadEmitted.deleteMany({})
    await prisma.$disconnect()
  })

  const getCtesCount = async () => {
    const { prisma } = createContext({})
    return await prisma.loadEmitted.count({})
  }
  const createCtes = async (createdAt: Date, quantity: number) => {
    const { prisma } = createContext({})

    const travelStatus = await prisma.travelStatus.create({
      data: {
        name: 'status'
      }
    })

    for (let i = 0; i < quantity; i++) {
      await prisma.loadEmitted.create({
        data: {
          load: { create: { ad_valorem: 1 } },
          travel_number: '1',
          travel: { create: { company: { create: { name: 'company' } }, load: { create: { ad_valorem: 1 } }, status: 'any' } },
          travel_status: travelStatus.id,
          created_at: createdAt,
          xml: 'xml',
          Issuer: {
            create: {
              name: 'issuer',
              ie: '12345678901234',
              phone: '123456789',
              document: '12345678901234',
              postal_code: '12345678',
              trading_name: 'issuer',
              address: 'issuer',
              number: '123',
              city: {
                connectOrCreate: {
                  where: { name: 'city' },
                  create: { name: 'city', province: { connectOrCreate: { where: { id: 1 }, create: { name: 'state', uf: 'st' } } } }

                }
              },
              company: {
                connectOrCreate: {
                  where: { id: 1 },
                  create: { name: 'company', id: 1 }
                }
              }
            }
          }
        }
      })
    }

    const loads = await prisma.loadEmitted.findMany({})

    return loads
  }
  it('should fail and return 422 Schema Validation Error when no filter is provided', async () => {
    // arrange
    const query = {}

    // act
    const response = await request(new ServiceServer().getApp()).get(PATH).query(query)

    // assert
    expect(response.statusCode).toBe(422)
    const error = response.body

    const [err] = error
    expect(err.message).toBe('Pelo menos um filtro deve ser inserido')
    expect(err.type).toBe(ErrorTypesEnum.SchemaValidation)
  })
  it('should fail and return 422 when date.to is provided but date.from is not provided', async () => {
    // arrange
    const query = { to: new Date() }

    // act
    const response = await request(new ServiceServer().getApp()).get(PATH).query(query)

    // assert
    expect(response.statusCode).toBe(422)
    const error = response.body

    const [err] = error
    expect(err.message).toBe('A data de inicio do filtro deve ser inserida')
    expect(err.type).toBe(ErrorTypesEnum.SchemaValidation)
  })
  it('should fail when date.from provided is greather than date.to', async () => {
    // arrange
    const query = { from: new Date(new Date().setDate(new Date().getDate() + 1)) }

    // act
    const a = new ServiceServer().getApp()
    const response = await request(a).get(PATH).query(query)
    // assert
    expect(response.statusCode).toBe(422)
    const error = response.body

    const [err] = error
    expect(err.message).toBe('A data de inicio deve ser menor que a data final')
    expect(err.type).toBe(ErrorTypesEnum.SchemaValidation)
  })
  it('should list ctes', async () => {
    // arrange

    const INSIDE_DATES_RANGE_QUANTITY = 5
    const OUTSIDE_DATES_RANGE_QUANTITY = 2
    const query = { from: new Date(new Date().setDate(new Date().getDate() - 3)), to: new Date() }

    await createCtes(new Date(new Date().setDate(new Date().getDate() - 1)), INSIDE_DATES_RANGE_QUANTITY)
    await createCtes(new Date(new Date().setDate(new Date().getDate() + 10)), OUTSIDE_DATES_RANGE_QUANTITY)

    const spyDates = jest.spyOn(getCtesHelper, 'queryBuilder')
    // act
    const response = await request(new ServiceServer().getApp()).get(PATH).query(query)

    // assert

    expect(spyDates).toHaveBeenCalledWith({
      from: new Date(query.from.setHours(0, 0, 0, 0)),
      to: new Date(new Date(query.to.setHours(23, 59, 59, 0)))
    })

    const allData = await getCtesCount()
    expect(allData).toBe(INSIDE_DATES_RANGE_QUANTITY + OUTSIDE_DATES_RANGE_QUANTITY)

    expect(response.statusCode).toBe(200)
    const { data, totalSize } = response.body.result

    expect(totalSize).toBe(INSIDE_DATES_RANGE_QUANTITY)
    expect(data.length).toBe(INSIDE_DATES_RANGE_QUANTITY)

    data.forEach(d => {
      expect(d.id).toBeDefined()
      expect(d.chave_cte).toBeDefined()
      expect(d.travel.id).toBeDefined()
      expect(d.travel.travel_number).toBeDefined()
    })
  })
})
