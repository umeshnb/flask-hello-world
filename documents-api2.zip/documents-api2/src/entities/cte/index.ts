/* eslint-disable @typescript-eslint/no-misused-promises */
import { Router } from 'express'
import { CteController } from './controller'

class CteRouter {
  private readonly router = Router()
  private readonly controller: CteController

  constructor () {
    this.controller = new CteController()
  }

  public run () {
    this.get()
    this.post()
    this.patch()
    this.delete()
    return this.router
  }

  private get () {
    this.router.get('/filter', this.controller.GetCtesController.getCtes)
  }

  private post () {
  }

  private patch () {
  }

  private delete () {
  }
}

export default new CteRouter()
