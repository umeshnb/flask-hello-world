import zod from 'zod'

export const zodPayloadGetCtesQuery = zod.object({
  cte_number: zod.string().optional(),
  chave_nf: zod.string().optional(),
  from: zod.date().optional().or(zod.string().optional()),
  to: zod.date().optional().or(zod.string().optional()),
  issuer_id: zod.number().optional(),
  taker_id: zod.number().optional()
})
  .superRefine((data, ctx) => {
    if (!Object.keys(data)?.length) {
      ctx.addIssue({
        code: zod.ZodIssueCode.custom,
        message: 'Pelo menos um filtro deve ser inserido'
      })
    }
  })

  .superRefine((data, ctx) => {
    if (data.to && !data.from) {
      ctx.addIssue({
        code: zod.ZodIssueCode.custom,
        message: 'A data de inicio do filtro deve ser inserida'
      })
    }
    if ((data.from && data.to) && new Date(data.from) > new Date(data.to)) {
      ctx.addIssue({
        code: zod.ZodIssueCode.custom,
        message: 'A data de inicio deve ser menor que a data final'
      })
    }
  })
export type PayloadGetCtesQuery = zod.infer<typeof zodPayloadGetCtesQuery>
