import { createContext } from '@cargon/client'
import axios from 'axios'
import { config } from '../../../config'
import { setResponse } from '../../../utils/helpers/httpHelper'
import { CancelNfeParams } from '../types'

const { prisma } = createContext({})

export const cancelNfe = async (data: CancelNfeParams, token: string, userId: number) => {
  const { nfe_keys, rebill } = data

  if (nfe_keys?.length > 0) {
    const emittedCtesRaw =
      (await prisma.nfeEmitted.groupBy({
        by: ['emitted_id'],
        where: {
          nfe: {
            chave_nf: {
              in: nfe_keys
            },
            deleted_at: null
          }
        }
      }))
        ?.filter(({ emitted_id }) => emitted_id !== null)
        ?.map(({ emitted_id }) => emitted_id)

    const { count: nfesCancelled } = await prisma.nfe.updateMany({
      where: {
        chave_nf: {
          in: nfe_keys
        },
        deleted_at: null
      },
      data: {
        deleted_at: new Date()
      }
    })

    const rebillValue = rebill !== undefined ? rebill : false

    if (emittedCtesRaw?.length > 0) {
      const emittedCtes = Array.from(new Set(emittedCtesRaw))
      await prisma.loadEmitted.updateMany({
        where: {
          id: {
            in: emittedCtes
          }
        },
        data: {
          rebill: rebillValue,
          emission_status_id: 4
        }
      })

      await prisma.emittedCancellationReasons.createMany({
        data: emittedCtes.map((emitted_id) => ({
          emitted_id,
          reason_id: 10,
          comment: 'Tomador cancelou a NFe',
          created_at: new Date(),
          user_id: userId
        }))
      })
      // cancelCtes(emittedCtes, token)
    }

    return setResponse({
      status: 200,
      result: { data: `${nfesCancelled} NFe(s) cancelada(s) com sucesso` }
    })
  }

  return setResponse({
    status: 200,
    result: { data: 'Nenhuma NFe foi cancelada' }
  })
}

export const cancelCtes = (emittedCtes: number[], token: string) => {
  emittedCtes.forEach((cteId) => {
    void axios.put(`${config.ISSUING_API_URL}/cte/cancel/${cteId.toString()}`, {
      slug: 'CANCELLED_NFE',
      comment: 'Tomador cancelou a NFe'
    },
      {
        headers: {
          'Content-Type': 'application/json',
          authorization: token
        }
      })
  })
}
