/* eslint-disable @typescript-eslint/no-misused-promises */
import { Router } from 'express'
import { NfeController } from './controller'

class NfeRouter {
  private readonly router = Router()
  private readonly controller: NfeController

  constructor () {
    this.controller = new NfeController()
  }

  public run () {
    this.get()
    this.post()
    this.patch()
    this.delete()
    return this.router
  }

  private get () {
  }

  private post () {
    this.router.post('/cancel', this.controller.CancelNfeController.cancelNfe)
  }

  private patch () {
  }

  private delete () {
  }
}

export default new NfeRouter()
