
export interface CancelNfeParams {
  nfe_keys: string[]
  rebill?: boolean
}
