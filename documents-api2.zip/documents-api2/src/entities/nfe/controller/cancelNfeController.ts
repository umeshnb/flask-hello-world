
import { Response } from 'express'
import { CargonRequest } from '../../../types'
import { CancelNfeParams } from '../types'
import { cancelNfe } from '../useCase/cancelNfe'

export class CancelNfeController {
  async cancelNfe(
    req: CargonRequest<CancelNfeParams>,
    res: Response
  ) {
    const { authorization } = req.headers
    const { data, status } = await cancelNfe(req.body, authorization as string, req.userId as number)
    return res.status(status).json(data)
  }
}
