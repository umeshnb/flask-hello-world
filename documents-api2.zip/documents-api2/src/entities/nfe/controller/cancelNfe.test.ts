import { createContext } from '@cargon/client'
import request from 'supertest'
import { ServiceServer } from '../../../interface'
import { removeDbConstraints } from '../../../utils/helpers/removeDbConstraints'
import * as CancelNfeModule from '../useCase/cancelNfe'
const PATH = '/nfe/cancel'

const { prisma } = createContext({})

const createManyLoadEmitteds = async (quantity: number) => {
  const travelStatus = await prisma.travelStatus.create({
    data: {
      name: 'status'
    }
  })
  for (let i = 0; i < quantity; i++) {
    await prisma.loadEmitted.create({
      data: {
        travel_status: travelStatus.id,
        travel_number: '1',
        rebill: true,
        load: {
          connectOrCreate: {
            where: {
              id: 1
            },
            create: {
              ad_valorem: 0
            }
          }
        },
        travel: {
          connectOrCreate: {
            where: {
              id: 1
            },
            create: {
              travel_number: '1',
              status: 'any',
              company: {
                connectOrCreate: {
                  where: {
                    id: 1
                  },
                  create: {
                    name: '1'
                  }
                }
              },
              load: {
                connectOrCreate: {
                  where: {
                    id: 1

                  },
                  create: {
                    ad_valorem: 0

                  }
                }
              }
            }

          }
        }
      }
    })
  }
}

describe('integration: cancel nfe', () => {
  beforeEach(async () => {
    jest.spyOn(CancelNfeModule, 'cancelCtes').mockImplementation(() => { })
  })

  afterEach(async () => {
    jest.clearAllMocks()
    jest.restoreAllMocks()

    const { prisma } = createContext({})
    await removeDbConstraints(prisma)

    await prisma.nfe.deleteMany()
    await prisma.loadEmitted.deleteMany()
    await prisma.nfeEmitted.deleteMany()
  })

  afterAll(async () => {
    const { prisma } = createContext({})
    await removeDbConstraints(prisma)

    await prisma.nfe.deleteMany()
    await prisma.loadEmitted.deleteMany()
    await prisma.nfeEmitted.deleteMany()
    await prisma.$disconnect()
  })

  it('should return 200 and brings nothing when no data is provided', async () => {
    // arrange
    const body = { nfe_keys: [] }

    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send(body)
      .expect('Content-Type', /json/)

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('Nenhuma NFe foi cancelada')
  })
  it('should return 200 and brings nothing when no nfe matchs the provided data', async () => {
    // arrange
    const body = {
      nfe_keys: ['12345678901234567890123456789012345678901234']
    }
    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send(body)

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('0 NFe(s) cancelada(s) com sucesso')
  })
  it('should return 200 and validate the filter to match the deleted_at equals null', async () => {
    await prisma.nfe.createMany({
      data: [
        {
          chave_nf: '1',
          deleted_at: null,
          emitted_id: null,
          nf_number: '1'
        },
        {
          chave_nf: '2',
          deleted_at: new Date(),
          emitted_id: null,
          nf_number: '2'
        }
      ]
    })
    const nfes = await prisma.nfe.findMany({})
    const body = nfes.map((nfe) => nfe.chave_nf)

    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send({ nfe_keys: body })

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('1 NFe(s) cancelada(s) com sucesso')
  })

  it('should return 200 and set deleted_at field as current date to all the nfes matching the criteria', async () => {
    // arrange
    await prisma.nfe.createMany({
      data: [
        {
          chave_nf: '1',
          deleted_at: null,
          emitted_id: null,
          nf_number: '1'
        },
        {
          chave_nf: '2',
          deleted_at: null,
          emitted_id: null,
          nf_number: '2'
        }
      ]
    })
    const nfes = await prisma.nfe.findMany({})
    const body = nfes.map((nfe) => nfe.chave_nf)

    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send({ nfe_keys: body })

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('2 NFe(s) cancelada(s) com sucesso')

    const nfesUpdated = await prisma.nfe.findMany({})
    const nfesUpdatedWithDeletedAt = nfesUpdated.filter((nfe) => nfe.deleted_at !== null)
    expect(nfesUpdatedWithDeletedAt.length).toEqual(2)
  })

  it('should return 200 and update the emitted nfes rebill to false when no rebill is provided', async () => {
    // arrange

    await createManyLoadEmitteds(2)
    const emitteds = await prisma.loadEmitted.findMany({ select: { id: true } })

    await prisma.nfe.createMany({
      data: [
        {
          chave_nf: '1',
          deleted_at: null,
          emitted_id: emitteds[0].id,
          nf_number: '1'
        },
        {
          chave_nf: '2',
          deleted_at: null,
          emitted_id: emitteds[1].id,
          nf_number: '2'
        }
      ]
    })

    const nfes = await prisma.nfe.findMany({})

    await prisma.nfeEmitted.createMany({
      data: [
        {

          nf_id: nfes[0].id,
          emitted_id: emitteds[0].id
        },
        {

          nf_id: nfes[1].id,
          emitted_id: emitteds[1].id
        }
      ]
    })

    const body = nfes.map((nfe) => nfe.chave_nf)

    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send({ nfe_keys: body })

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('2 NFe(s) cancelada(s) com sucesso')

    const nfesUpdated = await prisma.nfe.findMany({})
    const nfesUpdatedWithDeletedAt = nfesUpdated.filter((nfe) => nfe.deleted_at !== null)
    expect(nfesUpdatedWithDeletedAt.length).toEqual(2)

    const loadEmittedsUpdated = await prisma.loadEmitted.findMany({})
    const loadEmittedsUpdatedWithRebillFalse = loadEmittedsUpdated.filter((loadEmitted) => !loadEmitted.rebill)
    expect(loadEmittedsUpdatedWithRebillFalse.length).toEqual(2)
  })

  it('should return 200 and update the emitted nfes rebill to the value provided and cancel the nfe matching the criteria', async () => {
    // arrange

    await createManyLoadEmitteds(2)
    const emitteds = await prisma.loadEmitted.findMany({ select: { id: true } })
    await prisma.loadEmitted.update({
      where: {
        id: emitteds[0].id
      },
      data: {

        rebill: false
      }
    })

    await prisma.nfe.createMany({
      data: [
        {
          chave_nf: '1',
          deleted_at: null,
          emitted_id: emitteds[0].id,
          nf_number: '1'
        },
        {
          chave_nf: '2',
          deleted_at: null,
          emitted_id: emitteds[1].id,
          nf_number: '2'
        }
      ]
    })

    const nfes = await prisma.nfe.findMany({})
    const body = nfes.map((nfe) => nfe.chave_nf)[0]

    await prisma.nfeEmitted.createMany({
      data: [
        {

          nf_id: nfes[0].id,
          emitted_id: emitteds[0].id
        },
        {

          nf_id: nfes[1].id,
          emitted_id: emitteds[1].id
        }
      ]
    })

    // act
    const response = await request(new ServiceServer().getApp()).post(PATH).send({ nfe_keys: body, rebill: true })

    // assert
    expect(response.status).toBe(200)
    const { result: { data } } = response.body

    expect(data).toEqual('1 NFe(s) cancelada(s) com sucesso')

    const nfesUpdated = await prisma.nfe.findMany({})
    const nfesUpdatedWithDeletedAt = nfesUpdated.filter((nfe) => nfe.deleted_at !== null)
    expect(nfesUpdatedWithDeletedAt.length).toEqual(1)

    const loadEmittedsUpdated = await prisma.loadEmitted.findMany({})
    const loadEmittedsUpdatedWithRebillTrue = loadEmittedsUpdated.filter((loadEmitted) => loadEmitted.rebill)
    expect(loadEmittedsUpdatedWithRebillTrue.length).toEqual(2)
  })
})
