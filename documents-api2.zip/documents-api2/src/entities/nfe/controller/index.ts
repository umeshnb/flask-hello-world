import { CancelNfeController } from './cancelNfeController'

export class NfeController {
  CancelNfeController: CancelNfeController
  constructor () {
    this.CancelNfeController = new CancelNfeController()
  }
}
