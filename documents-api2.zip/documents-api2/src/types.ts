
import { Request } from 'express'
import { Types } from '@cargon/client'

export interface CargonRequest<
  T = any,
  ResBody = any,
  ReqBody = any,
  ReqQuery = any
> extends Request<T, ResBody, ReqBody, ReqQuery> {
  userId?: number
  user?: Types.User
}

export interface ResponsesUseCases<T> {
  status: number
  data: {
    result?: T
    message?: string
  }
}
