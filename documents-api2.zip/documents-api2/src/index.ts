/* eslint-disable no-console */
import { ServiceServer } from './interface'
import { config } from './config'

class ServiceStarter {
  private readonly Server: ServiceServer

  constructor () {
    this.Server = new ServiceServer()

    this.run()
  }

  run () {
    this.Server.run()
    this.handler()
  }

  handler () {
    console.log(`App started on Port: ${config.PORT}`)
    process.on('exit', () => {
      console.log('The application is being terminated')
    })
  }
}

new ServiceStarter()
export {}
