# Documents API
## Setup
```
npm i 
```

create a .env file and copy from the .env.example

## How to run
```
npm run dev
```

## Running tests
```
npm run docker:up
```
```
npm run migrate:mssql
```
```
npm run test --file
```

after running tests

```
npm run docker:down
```

